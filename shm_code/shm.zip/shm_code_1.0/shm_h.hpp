// c文件
#include <cstring>
#include <cerrno>
#include <cstdio>

// c++文件
#include <iostream>
// 系统文件
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <unistd.h>
